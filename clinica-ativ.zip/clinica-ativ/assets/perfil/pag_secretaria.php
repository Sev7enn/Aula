<!DOCTYPE html>
<html lang="pt-br">
	<head>
	<?php
		session_start();
		if($_SESSION["login"] != "SIM"){
			header("Location: pag_secretaria.php");
		}
	?>
		<meta charset="utf-8">
		<link rel="stylesheet" href="004_CSS.css">
	</head>
	<body>
		<div id="principal">
			<a href="cadastro_secretaria.html"><input type="button" name="Cadastrar" value="cadastrar"></a><br>
			<a href="agenda.php"><input type="button" name="Agendamentos" value="agendamentos"></a><br>
			<a href="004_Login_Sair.php"><input type="button" name="Sair" value="Sair"></a><br>
			
		</div>
	</body>
</html>