﻿<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" href="004_CSS.css">
	</head>
	<body>
		<?php 
			if(@$_POST["usuario"]=="administrador" && @$_POST["senha"]=="admin"){
				session_start();
				$_SESSION["login"] = "YES";
				$_SESSION["usuario"] = $_POST["usuario"];
				header("Location: pag_admin.php");
			}
			else if(@$_POST["usuario"]=="secretaria" && @$_POST["senha"]=="secretaria"){
				session_start();
				$_SESSION["login"] = "SIM";
				$_SESSION["usuario"] = $_POST["usuario"];
				header("Location: pag_secretaria.php");
			}
			else if(@$_POST["usuario"]=="medico" && @$_POST["senha"]=="medico"){
				session_start();
				$_SESSION["login"] = "Si";
				$_SESSION["usuario"] = $_POST["usuario"];
				header("Location: pag_medico.php");
			}
			else{
				session_start();
				$_SESSION["login"] = "NO";
				echo '<div id="principal">Você não tem permissão para acessar o conteúdo desta página</div>';
			}
		?>
		<a href="004_Login_Sair.php"><input type="button" name="sair" value="SAIR"></a>
	</body>
</html>