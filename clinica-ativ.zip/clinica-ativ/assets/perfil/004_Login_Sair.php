﻿<?php
	session_start();
	session_destroy();
	header("Location: 004_Login_1.php");
?>