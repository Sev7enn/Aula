<!DOCTYPE html>
<html lang="pt-br">
	<head>
	<?php
		session_start();
		if($_SESSION["login"] != "Si"){
			header("Location: pag_secretaria.php");
		}
	?>
		<meta charset="utf-8">
		<link rel="stylesheet" href="004_CSS.css">
		<title>P�GINA M�DICO</title>
	</head>
	<body>
		<div id="principal">
			<a href="agenda.php"><input type="button" name="Agendamentos" value="agendamentos"></a><br>
			<a href="004_Login_Sair.php"><input type="button" name="Sair" value="Sair"></a><br>
			
		</div>
	</body>
</html>