<?php //carrega.ph
	echo "<script type='text/javascript'>
		function redirect()
		{
			setInterval(function(){
			window.setTimeout('history.back(-2)', 5000);
				//window.location.href = 'cadastro_secretaria.html';
			}, 3000);
		}
	</script>";
	@$id   			 = "";
	@$n ome 			 = $_POST['nome'];
	@$data_nascimento = $_POST['nascimento'];
	@$telefone 		 = $_POST['telefone'];
	@$celular		 = $_POST['celular'];
	@$endereco 		 = $_POST['endereco'];
	@$numero		 	 = $_POST['numero'];
	@$complemento	 = $_POST['complemento'];
	@$bairro			 = $_POST['bairro'];
	@$estado			 = $_POST['estados'];
	@$cidade			 = $_POST['cidades'];
	@$email 		     = $_POST['email'];
	@$senha			 = $_POST['senha'];
	echo"senha = $senha<br>";
	@$senhacrip       = md5($senha);
	echo"$senhacrip<br>";
	@$repita_senha  	 = $_POST['senha2'];
	@$sexo 		     = $_POST['sexo'];
	@$obs 		     = $_POST['obs'];
	@$perfil 		 = 1;
		
		if($senha == $repita_senha){
		include "conexao.php";
		$sql = "INSERT INTO usuarios_tb VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		$usuarios =	$conectar -> prepare($sql);
		$usuarios -> execute(array( $id, $nome, $data_nascimento, $telefone, $celular, $endereco, $numero, $complemento, $bairro, $estado, $cidade, $email, $senhacrip,$sexo, $obs, $perfil));
		$conectar = null; 
		header("Location: novo_cadastro.html");
	}else{
		echo "Senhas Diferentes. Volte a p�gina antrerior!";
		
		echo "<script type='text/javascript'>redirect();</script>";
	}
	

	
?>