 <?php 

	/* arquivo para conexão com banco de dados*/
	try{	//tente

		$conectar = new PDO("mysql:host=localhost;dbname=ativ_bd", "root","");
		//echo "conexão efetuada";
	}
	catch(PDOException $e){	//bloco corresponde ao try

		//verificar var_dump($e);
		//verificar método echo $e->getCode();
		echo $e -> getMessage(); //método amplamente utilizado
	}
?>