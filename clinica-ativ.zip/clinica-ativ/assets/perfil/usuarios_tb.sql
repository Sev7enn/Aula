-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 24-Out-2016 às 20:38
-- Versão do servidor: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ativ_bd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios_tb`
--

CREATE TABLE `usuarios_tb` (
  `id` int(3) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `nascimento` date DEFAULT NULL,
  `telefone` varchar(10) DEFAULT NULL,
  `celular` varchar(10) DEFAULT NULL,
  `endereco` varchar(80) DEFAULT NULL,
  `numero` int(6) DEFAULT NULL,
  `complemento` int(6) DEFAULT NULL,
  `bairro` varchar(30) DEFAULT NULL,
  `estado` varchar(40) DEFAULT NULL,
  `cidade` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(10) DEFAULT NULL,
  `sexo` char(1) DEFAULT NULL,
  `obs` varchar(150) DEFAULT NULL,
  `perfil` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios_tb`
--

INSERT INTO `usuarios_tb` (`id`, `nome`, `nascimento`, `telefone`, `celular`, `endereco`, `numero`, `complemento`, `bairro`, `estado`, `cidade`, `email`, `senha`, `sexo`, `obs`, `perfil`) VALUES
(1, 'Andrei Vinicius Athanazio de araujo', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'andrei-vinicius@hotmail.com', NULL, NULL, NULL, NULL),
(2, 'Matheus Nogueira Pedron', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'matheus@lucem.org', NULL, NULL, NULL, NULL),
(3, 'Cezar', NULL, '(41)9527-0', NULL, 'rua: AndrÃ© Ferreira, 12', NULL, NULL, NULL, NULL, NULL, 'cezarjenzura@gmail.com', NULL, 'M', 'ceza', NULL),
(4, 'Cezar', NULL, '(41)9527-0', NULL, 'rua: AndrÃ© Ferreira, 12', NULL, NULL, NULL, NULL, NULL, 'cezarjenzura@gmail.com', NULL, 'M', 'ceza', 1),
(5, 'Gabriel', NULL, '(41)9990-2', NULL, 'rua: cascavel, 70', NULL, NULL, NULL, NULL, NULL, 'gabriel.carneiro@hotmail.com', NULL, 'M', 'obrigado pode continuar', 1),
(6, 'sarah', NULL, '(13)1351-3', NULL, 'rua: xuxuru,13', NULL, NULL, NULL, NULL, NULL, 'sara@gmail.xom', NULL, 'F', 'obs_sarah', 1),
(8, 'andrei', NULL, '(41)9990-2', NULL, 'rua: cascavel, 70', NULL, NULL, NULL, NULL, NULL, 'gabriel.carneiro@hotmail.com', NULL, 'M', 'wqeasd', 3),
(9, 'Cezar', NULL, '(41)9527-0', NULL, 'rua: AndrÃ© Ferreira, 12', NULL, NULL, NULL, NULL, NULL, 'cezarjenzura23@gmail.com', NULL, 'M', 'isso ai', 1),
(10, 'lucas', NULL, '(56)4564-6', NULL, 'alsnhoi 21', NULL, NULL, NULL, NULL, NULL, 'iashu@isuh.com', NULL, NULL, '', 3),
(11, 'lucas', NULL, '(56)4564-6', NULL, 'alsnhoi 21', NULL, NULL, NULL, NULL, NULL, 'iashu@isuh.com', NULL, 'M', 'saddsa', 2),
(12, 'vinÃ£o', NULL, '(65)4554-1', NULL, 'aoush, 25', NULL, NULL, NULL, NULL, NULL, 'vinao@yahoo.com', NULL, 'M', 'vinÃ£o pega no meu grÃ£o', 3),
(13, 'andrei', '1998-08-11', '(41)8761-2', '(41)8716-2', 'rua cascavel', 154, 45, 'boqueirÃ£o', NULL, NULL, 'andrei@gmail.com', 'andrei12', 'M', '', 1),
(16, 'andrei', '1998-01-11', '(65)4654-6', '(65)4654-6', 'rua cascavel', 654, 54, 'boqueirÃ£o', 'ParanÃ¡', 'Curitiba', 'andrei@gmail.com', 'andrei12', 'M', '', 1),
(17, 'andrei', '1998-08-11', '(41)5658-9', '(65)4654-6', 'rua trindade', 654, 45, 'cajuru', 'ParanÃ¡', 'Curitiba', 'andrei@gmail.com', 'andrei11', 'M', '', 1),
(18, 'andrei', '1998-08-11', '(41)5658-9', '(65)4654-6', 'rua trindade', 654, 45, 'cajuru', '', NULL, 'andrei@gmail.com', 'ANDREIPUTO', 'M', 'ASDAS', 1),
(19, 'andrei', '1998-08-11', '(41)5658-9', '(65)4654-6', 'rua trindade', 654, 45, 'cajuru', '', NULL, 'andrei@gmail.com', 'ANDREIPUTO', 'M', 'ASDAS', 1),
(20, 'andrei', '1998-08-11', '(41)5658-9', '(65)4654-6', 'rua trindade', 654, 45, 'cajuru', '', NULL, 'andrei@gmail.com', '4f79039c32', 'M', 'ASDAS', 1),
(21, 'andrei', '1998-08-11', '(41)5658-9', '(65)4654-6', 'rua trindade', 654, 45, 'cajuru', '', NULL, 'andrei@gmail.com', '202cb962ac', 'M', 'ASDAS', 1),
(22, 'andrei', '1998-08-11', '(41)5658-9', '(65)4654-6', 'rua trindade', 654, 45, 'cajuru', '', NULL, 'andrei@gmail.com', '202cb962ac', 'M', 'ASDAS', 1),
(23, 'andrei', '1998-08-11', '(41)5658-9', '(65)4654-6', 'rua trindade', 654, 45, 'cajuru', '', NULL, 'andrei@gmail.com', '202cb962ac', 'M', 'ASDAS', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `usuarios_tb`
--
ALTER TABLE `usuarios_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `usuarios_tb`
--
ALTER TABLE `usuarios_tb`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
