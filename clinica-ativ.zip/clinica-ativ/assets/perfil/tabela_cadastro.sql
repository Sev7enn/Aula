-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 24-Out-2016 às 20:38
-- Versão do servidor: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ativ_bd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tabela_cadastro`
--

CREATE TABLE `tabela_cadastro` (
  `id_cadastro` int(4) NOT NULL,
  `nome` varchar(60) DEFAULT NULL,
  `telefone` varchar(15) DEFAULT NULL,
  `endereco` varchar(70) DEFAULT NULL,
  `numero` varchar(6) DEFAULT NULL,
  `complemento` varchar(6) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `sexo` char(1) DEFAULT NULL,
  `obs` varchar(200) DEFAULT NULL,
  `perfil` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tabela_cadastro`
--

INSERT INTO `tabela_cadastro` (`id_cadastro`, `nome`, `telefone`, `endereco`, `numero`, `complemento`, `email`, `sexo`, `obs`, `perfil`) VALUES
(1, 'gabriel', '(04)1123-1231', 'rua jeronimo luiz fernandes, 60', NULL, NULL, 'andrei-vinicius@hotmail.com', 'M', '', '3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabela_cadastro`
--
ALTER TABLE `tabela_cadastro`
  ADD PRIMARY KEY (`id_cadastro`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabela_cadastro`
--
ALTER TABLE `tabela_cadastro`
  MODIFY `id_cadastro` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
