﻿<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<?php
		session_start();
		if(@$_SESSION['login'] == "YES"){
			header("Location: 004_Login_2.php");
		}else if( @$_SESSION['login'] == "SIM"){
			header("Location: 004_Login_2.php");
		} else if ( @$_SESSION['login'] == "Si"){
			header("Location: 004_Login_2.php");
		}		
		?>
		<meta charset="utf-8">
		<link rel="stylesheet" href="004_CSS.css">
	</head>
	<body>
		<div id="principal">
			<h1>Página de Login</h1>
			<form method="POST" action="004_Login_2.php">
				<fieldset>
					<legend>LOGIN</legend>
					Nome:<br>
					<input type="text" name="usuario" required>
					Senha:<br>
					<input type="password" name="senha" required>
					<br><br>
					<input type="submit" name="sub">
				</fieldset>
			</form>
		</div>
	</body>
</html>