<?php //inserir_admim.ph
	//
	@$id   			= "";
	@$nome 			= $_POST['nome'];
	@$telefone 		= $_POST['telefone'];
	@$endereco 		= $_POST['endereco'];
	@$numero		= $_POST['numero'];
	@$complemento	= $_POST['complemento'];
	@$email 	    = $_POST['email'];
	@$sexo 		    = $_POST['sexo'];
	@$obs 		    = $_POST['obs'];
	@$perfil 		= $_POST['perfil'];
		
		include "conexao.php";

		$sql = "INSERT INTO tabela_cadastro VALUES (?,?,?,?,?,?,?,?,?,?)";
		$usuarios =	$conectar -> prepare($sql);
		$usuarios -> execute(array( $id, $nome, $telefone, $endereco, $numero, $complemento, $email, $sexo, $obs, $perfil));
		$conectar = null; 
	

	header("Location: novo_cadastro.html");
?>